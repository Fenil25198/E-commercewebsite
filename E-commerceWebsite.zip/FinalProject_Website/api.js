fetch("https://apidojo-hm-hennes-mauritz-v1.p.rapidapi.com/regions/list", {
	"method": "GET",
	"headers": {
		"x-rapidapi-key": "SIGN-UP-FOR-KEY",
		"x-rapidapi-host": "apidojo-hm-hennes-mauritz-v1.p.rapidapi.com"
	}
})
.then(response => {
	console.log(response);
})
.catch(err => {
	console.error(err);
});