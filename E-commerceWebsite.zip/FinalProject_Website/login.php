<?php


$error = '';
if($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])){

  $email = trim($_POST['email']);
  $Password = trim($_POST['Password']);

  if(empty($email)){
    $error .='<p class="error">Please entre email.</p>';
  }
  if (empty($Password)){
    $error .='<p class="error">Please entre Password.</p>';
  }

  if(empty($error)){
    if($query = $db->prepare("SELECT * FROM users WHERE email =?")){
      $query->bind_param('s',$email);
      $query->excute();
      $row = $query->fetch();
      if($row){
        if (password_verify($Password, $row['password'])){
          $_SESSION["id"] = $row['id'];
          $_SESSION["email"] = $row;
         header("location: FinalProject.html");
    exit;
        }
        else{
          $error .='<p class="error">The password is not valid.</p>';
        }
      } else{
        $error .='<p class="error"> No user with that email.</p>';
      }
    }
    $query->close();
  }
  mysql_close($db);
}


?>
