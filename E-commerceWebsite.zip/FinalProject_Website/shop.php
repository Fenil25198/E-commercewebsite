
<?php

session_start();

require_once 'getdata.php';
require_once 'product.php';

// create instance of Createdb class
$database = new CreateDb('final_project', 'product_db'); //change ur db name
if (isset($_POST['add'])){
    /// print_r($_POST['product_id']);
    if(isset($_SESSION['cart'])){

        $item_array_id = array_column($_SESSION['cart'], "product_id");

        if(in_array($_POST['product_id'], $item_array_id)){
            echo "<script>alert('Product is already added in the cart..!')</script>";
            echo "<script>window.location = 'shop.php'</script>";
        }else{

            $count = count($_SESSION['cart']);
            $item_array = array(
                'product_id' => $_POST['product_id']
            );

            $_SESSION['cart'][$count] = $item_array;
        }

    }else{

        $item_array = array(
                'product_id' => $_POST['product_id']
        );

        // Create new session variable
        $_SESSION['cart'][0] = $item_array;
        print_r($_SESSION['cart']);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Shoping cart</title>
	<link rel="stylesheet" type="text/css" href="shopcart.css">
	<link rel="stylesheet" type="text/css" href="Website.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
	<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
	<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
	<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>


<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
<script type="text/javascript">
$(document).ready(function () {
$('.navbar-light .dmenu').hover(function () {
        $(this).find('.sm-menu').first().stop(true, true).slideDown(150);
    }, function () {
        $(this).find('.sm-menu').first().stop(true, true).slideUp(105)
    });
});
</script>

	<style type="text/css">
		.dropdown-large{ padding:1rem; }

		/* ============ desktop view ============ */
		@media all and (min-width: 992px) {
			.dropdown-large{min-width:500px;}
			@media screen and (max-width: 1300px) {
  nav li:not(:first-child) {display: none;}
  nav li.icon {
    float: right;
    display: block;
    color: black;
  }
}

@media screen and (max-width: 600px) {
  .navbar.responsive {position: relative;}
  .navbar.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
		}	
		/* ============ desktop view .end// ============ */
	</style>

	<script type="text/javascript">
		document.addEventListener("DOMContentLoaded", function(){
	        /////// Prevent closing from click inside dropdown
	        document.querySelectorAll('.dropdown-menu').forEach(function(element){
	        	element.addEventListener('click', function (e) {
	        		e.stopPropagation();
	        	});
	        })
	    }); 
		// DOMContentLoaded  end
	</script>
</head>
<body>

	<nav class="navbar navbar-expand-sm fixed-top navbar-light bg-light">
   	<img  class="logo" src="logo.png">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarTogglerDemo03">
          <ul class="navbar-nav mr-auto mt-2 mt-lg-0 ">
            <li class="nav-item">
              <a class="nav-link" href="finalProject.html">Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown"> Men </a>
              <div class="dropdown-menu  bg-light dropdown-large  sm-menu">
                <div class="row g-3">
                  <div class="col-4">
                    <h6 class="title">Faashion</h6> 
                    <ul class="list-unstyled">
                      <li><a href="#">Shirts </a></li>
                      <li><a href="#">Jeans </a></li>
                      <li><a href="#">shorts </a></li>
                      <li><a href="#"> </a></li>
                    
                      <li><a href="#">Shoes </a></li>
                      <li><a href="#">Watches </a></li>
                    </ul>

                  </div> 
                  <div class="col-4">
                    <h6 class="title">Outfit</h6>
                    <ul class="list-unstyled">
                      
                      <li><a href="#">Summer outfit </a></li>
                      <li><a href="#">Winter Outfit </a></li>
                      <li><a href="#">Classic </a></li>
                      <li><a href="#">Party Wear </a></li>
                    </ul>
                  </div>
                  <div class="col-4">
                    <h6 class="title">Accessories</h6>
                    <ul class="list-unstyled">
                      <li><a href="#">Belts </a></li>
                      <li><a href="#">Wallets </a></li>
                      <li><a href="#">Hats</a></li>
                      <li><a href="#">Ties</a></li>
                      <li><a href="#">Perfume </a></li>
                    
                    </ul>
                  </div>
                </div>
              </div> 
            </li>
             <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown"> Women </a>
              <div class="dropdown-menu  bg-light dropdown-large  sm-menu">
                <div class="row g-3">
                  <div class="col-4">
                    <h6 class="title">Faashion</h6> 
                    <ul class="list-unstyled">
                      <li><a href="#">Shirts </a></li>
                      <li><a href="#">Jeans </a></li>
                      <li><a href="#">shorts </a></li>
                      <li><a href="#"> </a></li>
                    
                      <li><a href="#">Shoes </a></li>
                      <li><a href="#">Watches </a></li>
                    </ul>

                  </div> 
                  <div class="col-4">
                    <h6 class="title">Outfit</h6>
                    <ul class="list-unstyled">
                      
                      <li><a href="#">Summer outfit </a></li>
                      <li><a href="#">Winter Outfit </a></li>
                      <li><a href="#">Classic </a></li>
                      <li><a href="#">Party Wear </a></li>
                    </ul>
                  </div>
                  <div class="col-4">
                    <h6 class="title">Accessories</h6>
                    <ul class="list-unstyled">
                      <li><a href="#">Belts </a></li>
                      <li><a href="#">Wallets </a></li>
                      <li><a href="#">Hats</a></li>
                      <li><a href="#">Ties</a></li>
                      <li><a href="#">Perfume </a></li>
                    
                    </ul>
                  </div>
                </div>
              </div> 
            </li>
             </li><li class="nav-item">
              <a class="nav-link" href="shop.php">Deal</a>
             </li>	
           
          <li class="nav-item">
            <a class="nav-link" href=contactus.php>Contact Us</a>
          </li>
          
          </ul>
   
          </div>
          <div class="Sc-button">
     <ul class="social-network social-circle">
          <li><a href="https://www.facebook.com/" class="icoFacebook" title="Facebook"><i class="fa fa-facebook"></i></a></li>
          <li><a href="https://twitter.com/Twitter?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor" class="icoTwitter" title="Twitter"><i class="fa fa-twitter"></i></a></li>
          <li><a href="#" class="icoGoogle" title="Google +"><i class="fa fa-google-plus"></i></a></li>
          <li><a href="https://www.linkedin.com/company/linkedin/" class="icoLinkedin" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
          <li><a href="Signup.php" class="sign-in" title="sign-in"><i class="fa fa-sign-in" ></i>
          	<li><a href="shopcart1.php" class="cart" title="cart"><i class="fas fa-shopping-cart" ></i>
          
            
</a></li>

  
</div>

        </div>
      </nav>
	

	<?php require_once 'getdata.php'; ?>
	<div style="padding-top: 30px;" class="container">
        <div class="row text-center py-5">
            <?php
                $result = $database->getData();

                while ($row = mysqli_fetch_assoc($result)) {
                    product($row['product_name'], $row['product_price'], $row['product_img'], $row['id']);
                }
            ?>

		</div>
	</div>
	<footer class=" text-center text-lg-start bg-secondary">

  <div class="container p-4">
  
    <div class="row">
      
      <div class="col-lg-6 col-md-12 mb-4 mb-md-0">
        <h5 class="text-uppercase">Pendemic</h5>

        <p>
         Join now and get 50% off 
        </p>
      </div>
     
      <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
        <h5 class="text-uppercase">Home</h5>

        <ul class="list-unstyled mb-0">
          <li>
            <a href="#!" class="text-dark">Men</a>
          </li>
          <li>
            <a href="#!" class="text-dark">Women</a>
          </li>
          <li>
            <a href="#!" class="text-dark">Kid</a>
          </li>
          <li>
            <a href="#!" class="text-dark">Fashion</a>
          </li>
        </ul>
      </div>
      
      <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
        <h5 class="text-uppercase mb-0">Help</h5>

        <ul class="list-unstyled">
          <li>
            <a href="#" class="text-dark">Contect us</a>
          </li>
          <li>
            <a href="#" class="text-dark">Return item</a>
          </li>
          <li>
            <a href="#" class="text-dark">Stores</a>
          </li>
          <li>
            <a href="#" class="text-dark">covid 19</a>
          </li>
        </ul>
      </div>
     
    </div>
     <div class="Sc-button">
     <ul class="social-network social-circle">
          <li><a href="https://www.facebook.com/" class="icoFacebook" title="Facebook"><i class="fa fa-facebook"></i></a></li>
          <li><a href="https://twitter.com/Twitter?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor" class="icoTwitter" title="Twitter"><i class="fa fa-twitter"></i></a></li>
          <li><a href="#" class="icoGoogle" title="Google +"><i class="fa fa-google-plus"></i></a></li>
          <li><a href="https://www.linkedin.com/company/linkedin/" class="icoLinkedin" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
          <li><a href="Signup.php" class="sign-in" title="sign-in"><i class="fa fa-sign-in" aria-hidden="true"></i>
</a></li>

  
</div>
  
  </div>
 

 
  <div class="text-center p-3" >
    © 2020 Copyright:
    <a class="text-dark" href="">CNPendemic.com</a>
  </div>
  
</footer>
</body>
</html>