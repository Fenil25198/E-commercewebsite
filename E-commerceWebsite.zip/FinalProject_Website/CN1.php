<?php

$con = mysqli_connect('localhost', 'root', '','final_project');

if($con === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
else {
	echo" welcome";
}

$FirstName = $_POST['FirstName'];
$LastName = $_POST['LastName'];
$Email = $_POST['email'];
$Password = $_POST['psw'];
$RePassword = $_POST['psw'];
$Number = $_POST['number'];
$sql = "INSERT INTO userdata (ID, FirstName, LastName, Email, Password, Number) VALUES('', '$FirstName', '$LastName', '$Email', '$Password', '$Number')";
	

if( mysqli_query($con, $sql)){
 header("location: FinalProject.html");
    exit;

 } 
else {
 	echo"please try again".mysqli_error($con);
 }

mysqli_close($con);





?>

